#!/bin/bash -ex
cd ~/devstack-stable-juno
./stack.sh
